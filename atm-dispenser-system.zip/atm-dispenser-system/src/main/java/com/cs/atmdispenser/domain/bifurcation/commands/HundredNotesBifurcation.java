package com.cs.atmdispenser.domain.bifurcation.commands;

import com.cs.atmdispenser.api.CurrencyType;

public class HundredNotesBifurcation extends AbstractNotesBifurcation {
    @Override
    public CurrencyType getCurrencyType() {
        return CurrencyType.CCY_100;
    }
}
