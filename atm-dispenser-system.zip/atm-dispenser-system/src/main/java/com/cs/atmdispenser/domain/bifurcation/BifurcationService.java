package com.cs.atmdispenser.domain.bifurcation;

import com.cs.atmdispenser.chain.Chain;
import com.cs.atmdispenser.repository.CurrencyBinRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BifurcationService {
  private CurrencyBinRepository repository;
  private Chain dispenserChain;

  @Autowired
  public BifurcationService(CurrencyBinRepository repository) {
    this.repository = repository;
  }

  public List<BifurcationData> bifurcate(int amount) {
    BifurcationContext context = new BifurcationContext();
    context.setAmount(amount);
    context.setRepository(repository);

    dispenserChain.execute(context);

    return context.getBifurcations();
  }

  @Autowired
  public void setDispenserChain(Chain dispenserChain) {
    this.dispenserChain = dispenserChain;
  }
}
