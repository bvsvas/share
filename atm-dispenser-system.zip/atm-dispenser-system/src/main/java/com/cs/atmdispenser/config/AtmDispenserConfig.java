package com.cs.atmdispenser.config;

import com.cs.atmdispenser.api.CurrencyType;
import com.cs.atmdispenser.chain.Chain;
import com.cs.atmdispenser.domain.bifurcation.commands.CheckAvailabilityCash;
import com.cs.atmdispenser.domain.bifurcation.commands.FiveHundredNotesBifurcation;
import com.cs.atmdispenser.domain.bifurcation.commands.HundredNotesBifurcation;
import com.cs.atmdispenser.domain.bifurcation.commands.ThousandNotesBifurcation;
import com.cs.atmdispenser.repository.CurrencyBinRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AtmDispenserConfig {

  @Bean
  public CurrencyBinRepository getCurrencyBinRepository() {
    CurrencyBinRepository currencyBinRepository = CurrencyBinRepository.getInstance();
    currencyBinRepository.addBin(CurrencyType.CCY_1000, 10);
    currencyBinRepository.addBin(CurrencyType.CCY_500, 100);
    currencyBinRepository.addBin(CurrencyType.CCY_100, 500);
    return currencyBinRepository;
  }

  @Bean
  public Chain dispenserChain() {
    Chain chain = new Chain();
    chain.add(new CheckAvailabilityCash());
    chain.add(new ThousandNotesBifurcation());
    chain.add(new FiveHundredNotesBifurcation());
    chain.add(new HundredNotesBifurcation());
    return chain;
  }

  /*
     @Bean
   public Chain dispenserChainWithThousandAdjustment() {
     Chain chain = new Chain();
     chain.add(new CheckAvailabilityCash());
     chain.add(new ThousandNotesBifurcation());
     chain.add(new FiveHundredNotesBifurcation());
     chain.add(new HundredNotesBifurcation());
     chain.add(new AdjustSmallDenominationIfThousandsOnly());
     return chain;
   }
  */
}
