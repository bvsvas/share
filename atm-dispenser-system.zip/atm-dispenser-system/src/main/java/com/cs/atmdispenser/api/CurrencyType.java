package com.cs.atmdispenser.api;

public enum CurrencyType {
  CCY_1000(1000),
  CCY_500(500),
  CCY_100(100);

  private int currency;

  CurrencyType(int value) {
    this.currency = value;
  }

  public int getCurrency() {
    return this.currency;
  }
}
