package com.cs.atmdispenser.domain.bifurcation;

import com.cs.atmdispenser.api.CurrencyType;
import com.cs.atmdispenser.chain.Context;
import com.cs.atmdispenser.repository.CurrencyBinRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BifurcationContext implements Context {
  private int amount;
  private int originalAmount;
  private List<BifurcationData> bifurcations = new ArrayList<>();
  private CurrencyBinRepository repository;
  private String message;

  public int getAmount() {
    return amount;
  }

  public void setAmount(int amount) {
    this.amount = amount;
  }

  public int getOriginalAmount() {
    return originalAmount;
  }

  public void setOriginalAmount(int originalAmount) {
    this.originalAmount = originalAmount;
  }

  public List<BifurcationData> getBifurcations() {
    return bifurcations;
  }

  public void addBifurcation(BifurcationData bifurcation) {
    if (bifurcation.isEmpty()) {
      return;
    }
    this.bifurcations.add(bifurcation);
  }

  public CurrencyBinRepository getRepository() {
    return repository;
  }

  public void setRepository(CurrencyBinRepository repository) {
    this.repository = repository;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public Optional<BifurcationData> getBifurcation(CurrencyType currencyType) {
    return bifurcations.stream()
        .filter(bifurcation -> bifurcation.getCurrencyType().equals(currencyType))
        .findFirst();
  }
}
