package com.cs.atmdispenser.chain;

public interface Command {
    boolean execute(Context context);
}
