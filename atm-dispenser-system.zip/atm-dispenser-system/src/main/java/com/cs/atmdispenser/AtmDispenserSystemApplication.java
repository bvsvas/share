package com.cs.atmdispenser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtmDispenserSystemApplication {

  public static void main(String[] args) {
    SpringApplication.run(AtmDispenserSystemApplication.class, args);
  }
}
