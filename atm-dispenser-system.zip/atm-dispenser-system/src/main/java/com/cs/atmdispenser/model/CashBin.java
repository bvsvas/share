package com.cs.atmdispenser.model;

import com.cs.atmdispenser.api.CurrencyType;

public class CashBin {
  private CurrencyType currencyType;
  private int count;

  public CashBin(CurrencyType currencyType, int count) {
    this.currencyType = currencyType;
    this.count = count;
  }

  public CurrencyType getCurrencyType() {
    return currencyType;
  }

  public void setCurrencyType(CurrencyType currencyType) {
    this.currencyType = currencyType;
  }

  public int getCount() {
    return count;
  }

  public void setCount(int count) {
    this.count = count;
  }

  public boolean isCashAvailable() {
    return count > 0;
  }

  public void decrementCount() {
    if (count <= 0) {
      throw new IllegalArgumentException("Insufficient Cash in the Bin");
    }
    count--;
  }

  public void decrementCount(int countToReduce) {
    if (count < countToReduce) {
      throw new IllegalArgumentException("Insufficient Cash in the Bin");
    }
    count -= countToReduce;
  }
}
