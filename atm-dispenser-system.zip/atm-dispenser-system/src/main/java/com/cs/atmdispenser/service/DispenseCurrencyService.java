package com.cs.atmdispenser.service;

import com.cs.atmdispenser.api.DispenseData;
import com.cs.atmdispenser.domain.CashBinUpdateService;
import com.cs.atmdispenser.domain.bifurcation.BifurcationData;
import com.cs.atmdispenser.domain.bifurcation.BifurcationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DispenseCurrencyService {

  @Autowired private BifurcationService bifurcationService;

  @Autowired private CashBinUpdateService cashBinUpdateService;

  @GetMapping("/dispense")
  public DispenseData dispense(@RequestParam("amount") Integer amount) {
    List<BifurcationData> bifurcations = bifurcationService.bifurcate(amount);
    DispenseData dispenseData = cashBinUpdateService.update(bifurcations);
    return dispenseData;
  }
}
