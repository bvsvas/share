package com.cs.atmdispenser.domain.bifurcation.commands;

import com.cs.atmdispenser.api.CurrencyType;
import com.cs.atmdispenser.chain.Command;
import com.cs.atmdispenser.chain.Context;
import com.cs.atmdispenser.domain.bifurcation.BifurcationContext;
import com.cs.atmdispenser.domain.bifurcation.BifurcationData;

public abstract class AbstractNotesBifurcation implements Command {

  @Override
  public boolean execute(Context context) {
    BifurcationContext bifurcationContext = (BifurcationContext) context;
    CurrencyType currencyType = getCurrencyType();
    int amount = bifurcationContext.getAmount();
    int availableCount = bifurcationContext.getRepository().getAvailableCount(currencyType);
    if (amount <= 0 || availableCount <= 0) {
      return true;
    }

    int currencyValue = currencyType.getCurrency();
    int count = amount / currencyValue;
    int remainingAmount = amount % currencyValue;

    BifurcationData bifurcationData = new BifurcationData(currencyType);
    bifurcationData.setCount(count);

    if (count > availableCount) {
      bifurcationData.setCount(availableCount);
      count -= availableCount;

      remainingAmount += count * currencyValue;
    }
    bifurcationContext.addBifurcation(bifurcationData);
    bifurcationContext.setAmount(remainingAmount);
    return true;
  }

  public abstract CurrencyType getCurrencyType();
}
