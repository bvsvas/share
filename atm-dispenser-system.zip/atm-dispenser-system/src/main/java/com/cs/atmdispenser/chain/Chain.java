package com.cs.atmdispenser.chain;

import java.util.ArrayList;
import java.util.List;

/** Kind of implementation of Apache Commons Chain */
public class Chain {
  private List<Command> commands = new ArrayList<>();

  //Exception Handling : unchecked currently
  public void execute(Context context) {
    for (Command command : commands) {
      if (!command.execute(context)) {
        break;
      }
    }
  }

  public void add(Command command) {
    commands.add(command);
  }
}
