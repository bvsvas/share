package com.cs.atmdispenser.chain;

public interface Context {
}
