package com.cs.atmdispenser.api;

import java.util.ArrayList;
import java.util.List;

public class DispenseData {

  private List<Denomination> denominations;

  public List<Denomination> getDenominations() {
    return denominations;
  }

  public void addDenomination(Denomination denomination) {
    if (denominations == null) {
      denominations = new ArrayList<>();
    }
    denominations.add(denomination);
  }

  public void setDenominations(List<Denomination> denominations) {
    this.denominations = denominations;
  }
}
