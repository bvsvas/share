package com.cs.atmdispenser.domain;

import com.cs.atmdispenser.api.Denomination;
import com.cs.atmdispenser.api.DispenseData;
import com.cs.atmdispenser.domain.bifurcation.BifurcationData;
import com.cs.atmdispenser.repository.CurrencyBinRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CashBinUpdateService {

  private CurrencyBinRepository repository;

  @Autowired
  public CashBinUpdateService(CurrencyBinRepository repository) {
    this.repository = repository;
  }

  public DispenseData update(List<BifurcationData> bifurcations) {
    DispenseData dispenseData = new DispenseData();

    List<Denomination> denominations =
        bifurcations.stream().map(this::update).collect(Collectors.toList());

    dispenseData.setDenominations(denominations);
    return dispenseData;
  }

  private Denomination update(BifurcationData bifurcationData) {
    repository.deduct(bifurcationData.getCurrencyType(), bifurcationData.getCount());
    return new Denomination(bifurcationData.getCurrencyType(), bifurcationData.getCount());
  }
}
