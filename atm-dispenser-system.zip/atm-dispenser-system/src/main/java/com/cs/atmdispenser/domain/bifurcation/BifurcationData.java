package com.cs.atmdispenser.domain.bifurcation;

import com.cs.atmdispenser.api.CurrencyType;

public class BifurcationData {
  private CurrencyType currencyType;
  private int count;

  public BifurcationData(CurrencyType currencyType) {
    this.currencyType = currencyType;
  }

  public CurrencyType getCurrencyType() {
    return currencyType;
  }

  public int getCount() {
    return count;
  }

  public void setCount(int count) {
    this.count = count;
  }

  public boolean isEmpty() {
    return count <= 0;
  }
}
