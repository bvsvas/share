package com.cs.atmdispenser.api;

public class Denomination {
  private CurrencyType currencyType;
  private int count;

  public Denomination(CurrencyType currencyType, int count) {
    this.currencyType = currencyType;
    this.count = count;
  }

  public CurrencyType getCurrencyType() {
    return currencyType;
  }

  public void setCurrencyType(CurrencyType currencyType) {
    this.currencyType = currencyType;
  }

  public int getCount() {
    return count;
  }

  public void setCount(int count) {
    this.count = count;
  }
}
