package com.cs.atmdispenser.domain.bifurcation.commands;

import com.cs.atmdispenser.chain.Command;
import com.cs.atmdispenser.chain.Context;
import com.cs.atmdispenser.domain.bifurcation.BifurcationContext;

public class CheckAvailabilityCash implements Command {
  @Override
  public boolean execute(Context context) {
    BifurcationContext bifurcationContext = (BifurcationContext) context;

    int availableAmount = bifurcationContext.getRepository().getAvailableAmount();
    if (availableAmount <= 0) {
      bifurcationContext.setMessage("Cash is not available, please try in other ATM");
      return false;
    }

    if (bifurcationContext.getAmount() > availableAmount) {
      bifurcationContext.setMessage("Cash is not enough, please try in other ATM");
      return false;
    }
    return true;
  }
}
