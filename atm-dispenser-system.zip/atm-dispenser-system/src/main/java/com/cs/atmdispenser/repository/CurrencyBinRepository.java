package com.cs.atmdispenser.repository;

import com.cs.atmdispenser.api.CurrencyType;
import com.cs.atmdispenser.model.BinKey;
import com.cs.atmdispenser.model.CashBin;

import java.util.LinkedHashMap;
import java.util.Map;

public class CurrencyBinRepository {
  private static final CurrencyBinRepository INSTANCE = new CurrencyBinRepository();

  private Map<BinKey, CashBin> dispenseBins = new LinkedHashMap<>();

  private CurrencyBinRepository() {
    // Avoid Construct outside
  }

  public static CurrencyBinRepository getInstance() {
    return INSTANCE;
  }

  public void deduct(CurrencyType currencyType, int count) {
    BinKey binKey = new BinKey(currencyType);
    CashBin cashBin = this.dispenseBins.get(binKey);
    if (cashBin != null) {
      cashBin.decrementCount(count);
    }
  }

  public int getAvailableCount(CurrencyType currencyType) {
    BinKey binKey = new BinKey(currencyType);
    CashBin cashBin = this.dispenseBins.get(binKey);
    return (cashBin != null) ? cashBin.getCount() : -1;
  }

  public int getAvailableAmount() {
    Integer amount =
        this.dispenseBins.values().stream()
            .map(cashBin -> cashBin.getCount() * cashBin.getCurrencyType().getCurrency())
            .reduce(0, (val1, val2) -> val1 + val2);
    return amount;
  }

  public void addBin(CurrencyType currencyType, int count) {
    BinKey binKey = new BinKey(currencyType);
    this.dispenseBins.put(binKey, new CashBin(currencyType, count));
  }

  public boolean isExists(BinKey binKey) {
    return this.dispenseBins.containsKey(binKey);
  }
}
