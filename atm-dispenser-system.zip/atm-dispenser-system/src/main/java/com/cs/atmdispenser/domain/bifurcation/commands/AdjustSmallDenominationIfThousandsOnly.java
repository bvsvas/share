package com.cs.atmdispenser.domain.bifurcation.commands;

import com.cs.atmdispenser.api.CurrencyType;
import com.cs.atmdispenser.chain.Command;
import com.cs.atmdispenser.chain.Context;
import com.cs.atmdispenser.domain.bifurcation.BifurcationContext;
import com.cs.atmdispenser.domain.bifurcation.BifurcationData;

import java.util.List;
import java.util.Optional;

public class AdjustSmallDenominationIfThousandsOnly implements Command {
  @Override
  public boolean execute(Context context) {
    BifurcationContext bifurcationContext = (BifurcationContext) context;
    // Ensure Minimum 5 hundreds and 1 Five hundred

    List<BifurcationData> bifurcations = bifurcationContext.getBifurcations();

    // Logic can be improvised further - very at high level adjustment
    Optional<BifurcationData> bifurcation1000 =
        bifurcationContext.getBifurcation(CurrencyType.CCY_1000);
    Optional<BifurcationData> bifurcation500 =
        bifurcationContext.getBifurcation(CurrencyType.CCY_500);
    Optional<BifurcationData> bifurcation100 =
        bifurcationContext.getBifurcation(CurrencyType.CCY_100);

    adjustThousand(bifurcationContext, bifurcation1000, bifurcation500, bifurcation100);
    return true;
  }

  private boolean adjustThousand(
      BifurcationContext bifurcationContext,
      Optional<BifurcationData> bifurcation1000,
      Optional<BifurcationData> bifurcation500,
      Optional<BifurcationData> bifurcation100) {
    boolean adjusted = false;
    if (bifurcation1000.isPresent()) {
      if (!bifurcation500.isPresent() && !bifurcation100.isPresent()) {
        int availableCount500 =
            bifurcationContext.getRepository().getAvailableCount(CurrencyType.CCY_500);
        int availableCount100 =
            bifurcationContext.getRepository().getAvailableCount(CurrencyType.CCY_100);
        if (availableCount500 >= 1 && availableCount100 >= 5) {
          // Both 500 and 100s available
          BifurcationData bifurcationData;
          bifurcationData = bifurcation1000.get();
          bifurcationData.setCount(bifurcationData.getCount() - 1);

          bifurcationData = new BifurcationData(CurrencyType.CCY_500);
          bifurcationData.setCount(1);
          bifurcationContext.addBifurcation(bifurcationData);

          bifurcationData = new BifurcationData(CurrencyType.CCY_100);
          bifurcationData.setCount(5);
          bifurcationContext.addBifurcation(bifurcationData);

          adjusted = true;
        } else if (availableCount500 >= 2 && availableCount100 <= 0) {
          BifurcationData bifurcationData;
          bifurcationData = bifurcation1000.get();
          bifurcationData.setCount(bifurcationData.getCount() - 1);

          bifurcationData = new BifurcationData(CurrencyType.CCY_500);
          bifurcationData.setCount(2);
          bifurcationContext.addBifurcation(bifurcationData);

          adjusted = true;
        } else if (availableCount100 >= 10) {
          BifurcationData bifurcationData;
          bifurcationData = bifurcation1000.get();
          bifurcationData.setCount(bifurcationData.getCount() - 1);

          bifurcationData = new BifurcationData(CurrencyType.CCY_100);
          bifurcationData.setCount(10);
          bifurcationContext.addBifurcation(bifurcationData);

          adjusted = true;
        }
      }
    }
    return adjusted;
  }
}
