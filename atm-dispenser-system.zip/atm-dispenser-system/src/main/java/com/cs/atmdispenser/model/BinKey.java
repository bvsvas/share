package com.cs.atmdispenser.model;

import com.cs.atmdispenser.api.CurrencyType;

public final class BinKey implements Comparable<CurrencyType> {
  private CurrencyType currencyType;

  public BinKey(CurrencyType currencyType) {
    this.currencyType = currencyType;
  }

  public CurrencyType getCurrencyType() {
    return currencyType;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    BinKey binKey = (BinKey) o;

    return currencyType == binKey.currencyType;
  }

  @Override
  public int hashCode() {
    return currencyType != null ? currencyType.hashCode() : 0;
  }

  @Override
  public int compareTo(CurrencyType o) {
    return this.currencyType.compareTo(o);
  }
}
