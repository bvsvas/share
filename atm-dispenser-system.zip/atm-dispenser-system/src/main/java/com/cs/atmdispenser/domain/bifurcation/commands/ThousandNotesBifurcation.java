package com.cs.atmdispenser.domain.bifurcation.commands;

import com.cs.atmdispenser.api.CurrencyType;

public class ThousandNotesBifurcation extends AbstractNotesBifurcation {

  @Override
  public CurrencyType getCurrencyType() {
    return CurrencyType.CCY_1000;
  }
}
