package com.cs.atmdispenser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtmDispenserSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
