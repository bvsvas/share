package com.cs.atmdispenser.domain.bifurcation;

import com.cs.atmdispenser.api.CurrencyType;
import com.cs.atmdispenser.domain.bifurcation.commands.AdjustSmallDenominationIfThousandsOnly;
import com.cs.atmdispenser.chain.Chain;
import com.cs.atmdispenser.domain.bifurcation.commands.CheckAvailabilityCash;
import com.cs.atmdispenser.domain.bifurcation.commands.FiveHundredNotesBifurcation;
import com.cs.atmdispenser.domain.bifurcation.commands.HundredNotesBifurcation;
import com.cs.atmdispenser.domain.bifurcation.commands.ThousandNotesBifurcation;
import com.cs.atmdispenser.repository.CurrencyBinRepository;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class BifurcationServiceTest {

  @Test
  void validate_Bifurcate_2000() {
    CurrencyBinRepository repository = CurrencyBinRepository.getInstance();
    repository.addBin(CurrencyType.CCY_1000, 2);
    repository.addBin(CurrencyType.CCY_500, 4);
    repository.addBin(CurrencyType.CCY_100, 5);

    BifurcationService bifurcationService = new BifurcationService(repository);
    Chain dispenserChain = dispenserChain();
    bifurcationService.setDispenserChain(dispenserChain);

    List<BifurcationData> bifurcations = bifurcationService.bifurcate(2000);
    assertNotNull(bifurcations);
    assertEquals(1, bifurcations.size());
    assertBifurcationData(CurrencyType.CCY_1000, 2, bifurcations.get(0));
  }

  @Test
  void validate_Bifurcate_1900() {
    CurrencyBinRepository repository = CurrencyBinRepository.getInstance();
    repository.addBin(CurrencyType.CCY_1000, 2);
    repository.addBin(CurrencyType.CCY_500, 4);
    repository.addBin(CurrencyType.CCY_100, 5);

    BifurcationService bifurcationService = new BifurcationService(repository);
    Chain dispenserChain = dispenserChain();
    bifurcationService.setDispenserChain(dispenserChain);

    List<BifurcationData> bifurcations = bifurcationService.bifurcate(1900);
    assertNotNull(bifurcations);
    assertEquals(3, bifurcations.size());
    assertBifurcationData(CurrencyType.CCY_1000, 1, bifurcations.get(0));
    assertBifurcationData(CurrencyType.CCY_500, 1, bifurcations.get(1));
    assertBifurcationData(CurrencyType.CCY_100, 4, bifurcations.get(2));
  }

  @Test
  void validate_Bifurcate_2000_With_Minimum_Denomination() {
    CurrencyBinRepository repository = CurrencyBinRepository.getInstance();
    repository.addBin(CurrencyType.CCY_1000, 2);
    repository.addBin(CurrencyType.CCY_500, 4);
    repository.addBin(CurrencyType.CCY_100, 5);

    BifurcationService bifurcationService = new BifurcationService(repository);

    Chain dispenserChain = dispenserChain();
    dispenserChain.add(new AdjustSmallDenominationIfThousandsOnly()); // Added new command to chain
    bifurcationService.setDispenserChain(dispenserChain);

    List<BifurcationData> bifurcations = bifurcationService.bifurcate(2000);
    assertNotNull(bifurcations);
    assertEquals(3, bifurcations.size());
    assertBifurcationData(CurrencyType.CCY_1000, 1, bifurcations.get(0));
    assertBifurcationData(CurrencyType.CCY_500, 1, bifurcations.get(1));
    assertBifurcationData(CurrencyType.CCY_100, 5, bifurcations.get(2));
  }

  @Test
  void validate_Bifurcate_4000_With_Minimum_Denomination() {
    CurrencyBinRepository repository = CurrencyBinRepository.getInstance();
    repository.addBin(CurrencyType.CCY_1000, 5);
    repository.addBin(CurrencyType.CCY_500, 1);
    repository.addBin(CurrencyType.CCY_100, 5);

    BifurcationService bifurcationService = new BifurcationService(repository);

    Chain dispenserChain = dispenserChain();
    dispenserChain.add(new AdjustSmallDenominationIfThousandsOnly()); // Added new command to chain
    bifurcationService.setDispenserChain(dispenserChain);

    List<BifurcationData> bifurcations = bifurcationService.bifurcate(4000);
    assertNotNull(bifurcations);
    assertEquals(3, bifurcations.size());
    assertBifurcationData(CurrencyType.CCY_1000, 3, bifurcations.get(0));
    assertBifurcationData(CurrencyType.CCY_500, 1, bifurcations.get(1));
    assertBifurcationData(CurrencyType.CCY_100, 5, bifurcations.get(2));
  }

  private void assertBifurcationData(
      CurrencyType currencyType, int count, BifurcationData bifurcation) {
    assertEquals(currencyType, bifurcation.getCurrencyType());
    assertEquals(count, bifurcation.getCount());
  }

  public Chain dispenserChain() {
    Chain chain = new Chain();
    chain.add(new CheckAvailabilityCash());
    chain.add(new ThousandNotesBifurcation());
    chain.add(new FiveHundredNotesBifurcation());
    chain.add(new HundredNotesBifurcation());
    return chain;
  }
}
